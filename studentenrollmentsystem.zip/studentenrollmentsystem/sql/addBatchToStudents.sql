-- Add column batch to students table

ALTER TABLE students ADD COLUMN `batch` int;
