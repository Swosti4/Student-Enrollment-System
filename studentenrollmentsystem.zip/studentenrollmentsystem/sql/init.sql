CREATE TABLE application_users
(
    id                int auto_increment primary key,
    username         varchar(255),
    password         varchar(255)    
);

INSERT INTO `application_users` (`id`, `username`, `password`) VALUES (NULL, 'admin', 'admin');

CREATE TABLE courses
(
    id                int auto_increment primary key,
    courseName         varchar(255)    
);

CREATE TABLE students
(
    id                int auto_increment primary key,
    firstName         varchar(255),
    middleName        varchar(255),
    lastName          varchar(255),
    dob               date,
    email             varchar(255),
    mobileNumber      varchar(255),
    gender            varchar(255),
    `address`         varchar(255),
    faculty           varchar(255),
    passedYear        varchar(4),
    gpa               varchar(255),
    courseId          int,
    countryAppliedFor varchar(255),
    classShift        varchar(255),
    FOREIGN KEY (courseId) REFERENCES courses(id)
);
