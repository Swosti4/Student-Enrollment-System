Create database enrollment_db \
Run the init.sql query inside the sql folder \
Goto backend/db_connection.php and change the username and password for database \
Open terminal in the studentenrollmentsystem and run \
php -S localhost:8080 \
Goto browser and enter localhost:8080