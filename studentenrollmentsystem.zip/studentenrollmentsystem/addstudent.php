<?php
require_once 'backend/db_connection.php';
require_once 'backend/retrieve_students.php';
require_once 'backend/retrieve_courses.php';

error_reporting(E_ERROR | E_PARSE);

$student_id = $_GET['id'];

$student = getSudentById($conn, $student_id);
$courses = getAllCourses($conn);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $firstName = $_POST["firstName"];
    $middleName = $_POST["middleName"];
    $lastName = $_POST["lastName"];
    $dob = $_POST["dob"];
    $email = $_POST["email"];
    $mobileNumber = $_POST["mobileNumber"];
    $gender = $_POST["gender"];
    $address = $_POST["address"];
    $faculty = $_POST["faculty"];
    $passedYear = $_POST["passedYear"];
    $gpa = $_POST["gpa"];
    $courseId = $_POST["courseId"];
    $countryAppliedFor = $_POST["countryAppliedFor"];
    $classShift = $_POST["classShift"];
    $batch = $_POST["batch"];

    if ($student_id !== Null) {
        $sql = "UPDATE students SET firstName=?, middleName=?, lastName=?, dob=?, email=?, mobileNumber=?, gender=?, `address`=?, faculty=?, passedYear=?, gpa=?, courseId=?, countryAppliedFor=?, classShift=?, batch=? WHERE id=?";
        $stmt = $conn->prepare($sql);

        $stmt->bind_param("ssssssssssssssii", $firstName, $middleName, $lastName, $dob, $email, $mobileNumber, $gender, $address, $faculty, $passedYear, $gpa, $courseId, $countryAppliedFor, $classShift, $batch,$student_id);

        if ($stmt->execute()) {
            header("Location: viewstudent.php");
        } else {
            header("Location: failure.php");
        }

        $stmt->close();
    } else {
        $sql = "INSERT INTO students (firstName, middleName, lastName, dob, email, mobileNumber, gender, `address`, faculty, passedYear, gpa, courseId, countryAppliedFor, classShift, batch) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

        $stmt = $conn->prepare($sql);

        $stmt->bind_param("ssssssssssssssi", $firstName, $middleName, $lastName, $dob, $email, $mobileNumber, $gender, $address, $faculty, $passedYear, $gpa, $courseId, $countryAppliedFor, $classShift,$batch);

        if ($stmt->execute()) {
            header("Location: viewstudent.php");
        } else {
            header("Location: failure.php");
        }

        $stmt->close();
    }
}
?>

<?php include('sidebar.php'); ?>
<div class="content">
    <form method="post">
        <h3 class="mb-4">Enroll a Student</h3>
        <div class="form-row">
            <div class="form-group col-md-4">
                
            <label for="firstName">First Name:</label>
                <input type="text" class="form-control" id="firstName" name="firstName" value="<?php echo ($student !== Null) ? $student['firstName'] : ''; ?>" required>
            </div>
            <div class="form-group col-md-4">
                <label for="middleName">Middle Name:</label>
                <input type="text" class="form-control" id="middleName" name="middleName" value="<?php echo ($student !== Null) ? $student['middleName'] : ''; ?>" >
            </div>
            <div class="form-group col-md-4">
                <label for="lastName">Last Name:</label>
                <input type="text" class="form-control" id="lastName" name="lastName" value="<?php echo ($student !== Null) ?  $student['lastName'] : ''; ?>" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-4">
                <label for="dob">Date of Birth:</label>
                <input type="date" class="form-control" id="dob" name="dob" value="<?php echo ($student !== Null) ?  $student['dob'] : ''; ?>" required>
            </div>
            <div class="form-group col-md-4">
                <label class="form-check-label">Gender:</label>
                <div class="form-check">
                    <input type="radio" class="form-check-input" name="gender" id="male"  value="Male" <?php echo ($student !== Null) ?  (($student['gender'] == 'Male') ? 'checked' : '') : ''; ?>>
                    <label for="male">Male</label>
                    <input type="radio" class="form-check-input" name="gender" id="female"  value="Female"<?php echo ($student !== Null) ?  (($student['gender'] == 'Female') ? 'checked' : '') : ''; ?>>
                    <label for="female">Female</label>
                    <input type="radio" class="form-check-input" name="gender" id="others" value="Others" <?php echo ($student !== Null) ?  (($student['gender'] == 'Others') ? 'checked' : '') : ''; ?>>
                    <label class="form-check-label" for="others">Others</label>
                </div>
            </div>
            <div class="form-group col-md-4">
                <label for="address">Address:</label>
                <input type="text" class="form-control" id="address" name="address" value="<?php echo ($student !== Null) ?  $student['address'] : ''; ?>" placeholder="Enter address">
            </div>
        </div>
        <div class="form-row">         
            <div class="form-group col-md-4">
                <label for="mobileNumber">Mobile Number:</label>
                <input type="number" class="form-control" id="mobileNumber" name="mobileNumber" value="<?php echo ($student !== Null) ?  $student['mobileNumber'] : ''; ?>" placeholder="Enter number">
            </div>
            <div class="form-group col-md-4">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo ($student !== Null) ?  $student['email'] : ''; ?>" placeholder="Enter email">
            </div>
            <div class="form-group col-md-4">
                <label for="address">Enrollment Batch:</label>
                <input type="number" class="form-control" id="batch" name="batch" value="<?php echo ($student !== Null) ?  $student['batch'] : ''; ?>" placeholder="Enter batch">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-4">
                <label for="faculty">Faculty:</label>
                <select class="form-control" id="faculty" name="faculty" required>
                    <option value="">Select Faculty</option>
                    <option value="Management" <?php echo ($student !== Null) ?  (($student['faculty'] == 'Management') ? 'selected="selected"' : '') : ''; ?>>Management</option>
                    <option value="Science" <?php echo ($student !== Null) ?  (($student['faculty'] == 'Science') ? 'selected="selected"' : '') : ''; ?>>Science</option>
                    <option value="Bachelor" <?php echo ($student !== Null) ?  (($student['faculty'] == 'Bachelor') ? 'selected="selected"' : '') : ''; ?>>Bachelor</option>
                    <option value="Diploma" <?php echo ($student !== Null) ?  (($student['faculty'] == 'Diploma') ? 'selected="selected"' : '') : ''; ?>>Diploma</option>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="passedYear">Passed Year:</label>
                <input type="number" class="form-control" id="passedYear" name="passedYear" value="<?php echo ($student !== Null) ?  $student['year'] : ''; ?>" placeholder="Enter passed year" required>
            </div>
            <div class="form-group col-md-4">
                <label for="gpa">GPA:</label>
                <input type="text" class="form-control" id="gpa" name="gpa" value="<?php echo ($student !== Null) ?  $student['gpa'] : ''; ?>" placeholder="Enter GPA" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-4">
                <label for="courseId">Course:</label>
                <select class="form-control" id="courseId" name="courseId" required>
                    <option value="">Select Course</option>
                    <?php
                    if ($courses !== Null) {
                        while ($course = $courses->fetch_assoc()) {
                            echo '<option value="' . $course["id"] . '"' . (($student !== Null) ?  (($student["courseId"] == $course["id"]) ? 'selected="selected"' : '') : '') . ' >' . $course["courseName"] . '</option>';
                        }
                    } ?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="countryAppliedFor">Country applied for:</label>
                <select class="form-control" id="countryAppliedFor" name="countryAppliedFor" required>
                    <option value="">Select Country</option>
                    <option value="Australia" <?php echo ($student !== Null) ?  (($student['countryAppliedFor'] == 'Australia') ? 'selected="selected"' : '') : ''; ?>>Australia</option>
                    <option value="USA" <?php echo ($student !== Null) ?  (($student['countryAppliedFor'] == 'USA') ? 'selected="selected"' : '') : ''; ?>>USA</option>
                    <option value="Dubai" <?php echo ($student !== Null) ?  (($student['countryAppliedFor'] == 'Dubai') ? 'selected="selected"' : '') : ''; ?>>Dubai</option>
                    <option value="New Zealand" <?php echo ($student !== Null) ?  (($student['countryAppliedFor'] == 'New Zealand') ? 'selected="selected"' : '') : ''; ?>>New Zealand</option>
                    <option value="Canada" <?php echo ($student !== Null) ?  (($student['countryAppliedFor'] == 'Canada') ? 'selected="selected"' : '') : ''; ?>>Canada</option>
                    <option value="UK" <?php echo ($student !== Null) ?  (($student['countryAppliedFor'] == 'UK') ? 'selected="selected"' : '') : ''; ?>>UK</option>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="classShift">Class Shift:</label>
                <select class="form-control" id="classShift" name="classShift" required>
                    <option value="">Select shift</option>
                    <option value="Morning" <?php echo ($student !== Null) ?  (($student['classShift'] == 'Morning') ? 'selected="selected"' : '') : ''; ?>>Morning</option>
                    <option value="Day" <?php echo ($student !== Null) ?  (($student['classShift'] == 'Day') ? 'selected="selected"' : '') : ''; ?>>Day</option>
                    <option value="Evening" <?php echo ($student !== Null) ?  (($student['classShift'] == 'Evening') ? 'selected="selected"' : '') : ''; ?>>Evening</option>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-12 text-center">
                <input type="submit" class="btn btn-primary" value="Add Student">
                <input type="reset" class="btn btn-secondary" value="Reset">
            </div>
        </div>
    </form>
</div>

<?php include("footer.php"); ?>