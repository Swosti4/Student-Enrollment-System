<?php
// Check if application user is logged in
session_start();
if (!isset($_SESSION["loggedin"]) || (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === false)) {
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Himalayan White House Education Consultancy</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>

<body>
    <div id="wrapper">
        <nav class="sidebar">
            <div class="profile-photo">
                <p><img src="images/profile.jpg" alt="">&nbsp;<?php echo (isset($_SESSION["username"]) ? $_SESSION["username"]  : '') ?></p>
            </div>
            <ul>
                <li><a href="dashboard.php" class="active">Dashboard</a></li>
                <li><a href="addcourse.php">Add Course</a></li>
                <li><a href="addstudent.php">Enroll Student</a></li>
                <li><a href="viewcourse.php">Courses</a></li>
                <li><a href="viewstudent.php">Students</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
        <div class="main-content">
            <div class="header-content">
                <header>
                    <div class="logo">
                        <img src="images/3rd.jpg" width="250px">
                        <strong>Himalayan White House Education Consultancy</strong>
                    </div>
                </header>
                <div class="topnav"></div>
            </div>