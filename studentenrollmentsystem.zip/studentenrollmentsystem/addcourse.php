<?php
require_once 'backend/db_connection.php';
require_once 'backend/retrieve_courses.php';

error_reporting(E_ERROR | E_PARSE);

$course_id = $_GET['id'];

$course = getCourseById($conn, $course_id);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $courseName = $_POST["courseName"];
    echo '<pre>';

    if ($course_id !== Null) {
        $sql = "UPDATE courses SET courseName=? WHERE id=?";
        $stmt = $conn->prepare($sql);

        $stmt->bind_param("si", $courseName, $course_id);

        if ($stmt->execute()) {
            header("Location: viewcourse.php");
        } else {
            header("Location: failure.php");
        }

        $stmt->close();
    } else {
        $sql = "INSERT INTO courses (courseName) VALUES (?)";

        $stmt = $conn->prepare($sql);

        $stmt->bind_param("s", $courseName);

        if ($stmt->execute()) {
            header("Location: viewcourse.php");
        } else {
            header("Location: failure.php");
        }

        $stmt->close();
    }
}
?>

    <?php include('sidebar.php');?>
    <div class="content">
        <form method="post">
            <h3 class="mb-4">Register a Course</h3>
            <div class="form-row">
                <div class="form-group col-md-12">
                    <label for="courseName">Course Name:</label>
                    <input type="text" class="form-control" id="courseName" name="courseName" value="<?php echo ($course !== Null) ? $course['courseName'] : ''; ?>" required>
                </div>             
            </div>            
            <div class="form-row">
                <div class="form-group col-md-12 text-center">
                    <input type="submit" class="btn btn-primary" value="Create">
                    <input type="reset" class="btn btn-secondary" value="Reset">
                </div>
            </div>
        </form>
    </div>

    
    <?php include("footer.php");?>