<?php

function getAllCourses($conn)
{
    $fetch_query = "SELECT id, courseName FROM courses";

    return $conn->query($fetch_query);
}

function getCourseById($conn, $id)
{
    $fetch_query = "SELECT id, courseName FROM courses WHERE id=?";
    $stmt = $conn->prepare($fetch_query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result(); 
    return $result->fetch_assoc();
}

function getAllCoursesCount($conn)
{
    $result = $conn->query("SELECT COUNT(id) as courseCount FROM courses");
    $row = $result->fetch_assoc();
    return $row['courseCount'];
}