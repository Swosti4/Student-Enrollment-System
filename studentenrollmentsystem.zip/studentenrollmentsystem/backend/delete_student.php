<?php
require_once 'db_connection.php';

$student_id = $_GET['id'];

$sql = "DELETE FROM students WHERE id=?";

$stmt = $conn->prepare($sql);

$stmt->bind_param("i", $student_id);

if ($stmt->execute()) {
    header("Location: ../viewstudent.php");
} else {
    header("Location: ../failure.php");
}

$stmt->close();

// todo: Add SQL query to delete the student by id then redirect to the viewstudent.php page using header("Location: viewstudent.php");
?>