<?php
require_once 'db_connection.php';

$course_id = $_GET['id'];

$sql = "DELETE FROM courses WHERE id=?";

$stmt = $conn->prepare($sql);

$stmt->bind_param("i", $course_id);

if ($stmt->execute()) {
    header("Location: ../viewcourse.php");
} else {
    header("Location: ../failure.php");
}

$stmt->close();

// todo: Add SQL query to delete the course by id then redirect to the viewcourse.php page using header("Location: viewcourse.php");
?>