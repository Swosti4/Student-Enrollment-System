<?php

// Database configuration
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'enrollment_db';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}