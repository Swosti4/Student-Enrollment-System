<?php

function isValidUser($conn, $username, $password)
{
    $fetch_query = "SELECT * FROM application_users WHERE username=? and password=?";
    $stmt = $conn->prepare($fetch_query);
    $stmt->bind_param("ss", $username,$password);
    $stmt->execute();
    $result = $stmt->get_result(); 
    return $result->fetch_assoc();
}

