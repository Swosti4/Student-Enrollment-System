<?php

function getAllStudents($conn)
{
    $fetch_query = "SELECT s.id as id, firstName, middleName, lastName, dob, email, mobileNumber, gender, `address`, faculty, passedYear, gpa, c.courseName as course, countryAppliedFor, classShift , batch
    FROM students s JOIN
    courses c ON s.courseId = c.id ORDER BY id ASC";

    return $conn->query($fetch_query);
}

function getSudentById($conn, $id)
{
    $fetch_query = "SELECT s.id as id, firstName, middleName, lastName, dob, email, mobileNumber, gender, `address`, faculty, passedYear, gpa, courseId, countryAppliedFor, classShift , batch
    FROM students s JOIN
    courses c ON s.courseId = c.id
    WHERE s.id=?";
    $stmt = $conn->prepare($fetch_query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function getAllStudentsCount($conn)
{
    $result = $conn->query("SELECT COUNT(id) as studentCount FROM students");
    $row = $result->fetch_assoc();
    return $row['studentCount'];
}

function getAllStudentBySearch($conn, $search_firstname, $search_batch)
{
    $stmt = Null;

    $firstname = trim(strtolower($search_firstname));
    $fetch_query = "SELECT s.id as id, firstName, middleName, lastName, dob, email, mobileNumber, gender, `address`, faculty, passedYear, gpa, c.courseName as course, countryAppliedFor, classShift , batch
    FROM students s JOIN
    courses c ON s.courseId = c.id";

    if ($search_firstname != '' && $search_batch != '') {
        $fetch_query =  $fetch_query . " WHERE LOWER(s.firstName)=? AND s.batch=?";
        $stmt = $conn->prepare($fetch_query);
        $stmt->bind_param("si", $firstname, $search_batch);
    } elseif ($search_firstname != '') {
        $fetch_query =  $fetch_query . " WHERE LOWER(s.firstName)=?";
        $stmt = $conn->prepare($fetch_query);
        $stmt->bind_param("s", $firstname);
    } elseif ($search_batch != '') {
        $fetch_query =  $fetch_query . " WHERE s.batch=?";
        $stmt = $conn->prepare($fetch_query);
        $stmt->bind_param("i", $search_batch);
    }

    if ($stmt == Null) {
        return $stmt;
    }

    $stmt->execute();
    $result = $stmt->get_result();
    return $result;
}

function getAllSBatch($conn)
{
    $fetch_query = "SELECT distinct batch as batch FROM students s JOIN courses c ON s.courseId = c.id";
    return $conn->query($fetch_query);
}
