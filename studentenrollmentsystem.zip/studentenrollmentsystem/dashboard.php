<?php
require_once 'backend/db_connection.php';
require_once 'backend/retrieve_students.php';
require_once 'backend/retrieve_courses.php';

$studentCount = getAllStudentsCount($conn);
$courseCount = getAllCoursesCount($conn);

?>
<?php include('sidebar.php'); ?>
<div class="content">
    <!--main section start-->
    <main>
        <div class="insights">
            <!--start student-->
            <div class="student">
                <span class="material-symbols-outlined">person_outline</span>
                <div class="middle">
                    <div class="left">
                        <h3>Total Student</h3>
                        <h1><?php echo $studentCount ?></h1>
                        <a href="viewstudent.php">Students</a>
                    </div>

                </div>
            </div>
            <!--end student-->
        </div>
        <div class="insights">
            <!--SAT Students-->
            <div class="course">
                <span class="material-symbols-outlined">menu_book</span>
                <div class="middle">
                    <div class="left">
                        <h3>SAT</h3>
                        <div class="left">
                            <h1>No. of Students</h1>
                            <?php
                            $count = "Select * from students where courseId=1";
                            $c = mysqli_query($conn, $count);
                            $row = mysqli_num_rows($c);
                            ?>
                        </div>
                        <h1><?php echo $row ?></h1>
                        <a href="viewsat.php">SAT</a>
                    </div>
                </div>
            </div>
            <!--end course-->

            <!--TOEFL Students-->
            <div class="course">
                <span class="material-symbols-outlined">menu_book</span>
                <div class="middle">
                    <div class="left">
                        <h3>TOEFL</h3>
                        <div class="left">
                            <h1>No. of Students</h1>
                            <?php
                            $count1 = "Select * from students where courseId=2";
                            $c1 = mysqli_query($conn, $count1);
                            $row1 = mysqli_num_rows($c1);
                            ?>
                        </div>
                        <h1><?php echo $row1 ?></h1>
                        <a href="viewtoefl.php">TOEFL</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="insights">
            <!--PTE Students-->
            <div class="course">
                <span class="material-symbols-outlined">menu_book</span>
                <div class="middle">
                    <div class="left">
                        <h3>PTE</h3>
                        <div class="left">
                            <h1>No. of Students</h1>
                            <?php
                            $count2 = "Select * from students where courseId=3";
                            $c2 = mysqli_query($conn, $count2);
                            $row2 = mysqli_num_rows($c2);
                            ?>
                        </div>
                        <h1><?php echo $row2 ?></h1>
                        <a href="viewpte.php">PTE</a>
                    </div>
                </div>
            </div>

            <!--IELTS Students-->
            <div class="course">
                <span class="material-symbols-outlined">menu_book</span>
                <div class="middle">
                    <div class="left">
                        <h3>IELTS</h3>
                        <div class="left">
                            <h1>No. of Students</h1>
                            <?php
                            $count3 = "Select * from students where courseId=4";
                            $c3 = mysqli_query($conn, $count3);
                            $row3 = mysqli_num_rows($c3);
                            ?>
                        </div>
                        <h1><?php echo $row3 ?></h1>
                        <a href="viewielts.php">IELTS</a>
                    </div>
                </div>
            </div>
        </div>
    </main>


</div>


<?php include("footer.php"); ?>