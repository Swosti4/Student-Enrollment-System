<?php
require_once 'backend/db_connection.php';
require_once 'backend/retrieve_students.php';


$batch_list = getAllSBatch($conn);

$search_firstname = Null;
$search_batch = Null;

if (
  $_SERVER["REQUEST_METHOD"] == "POST" && (!isset($_POST['reset']))
  && (isset($_POST['search_batch']) || isset($_POST['search_firstname'])) && 
  ($_POST['search_firstname'] != '' || $_POST['search_batch'] != '') 
) {
  $search_firstname = $_POST['search_firstname'];
  $search_batch = $_POST['search_batch'];
  $students = getAllStudentBySearch($conn, $search_firstname, $search_batch);
} else {
  $search_firstname = Null;
  $search_batch = Null;
  $students = getAllStudents($conn);
}



?>
<?php include('sidebar.php'); ?>
<div class="content">
  <div class="card border">
    <h3 class="text-white mb-4">Student Details</h3>
    <form method="post">
      <div class="form-row">
        <div class="form-group col-md-4">
          <input type="text" class="form-control" name="search_firstname" placeholder="Search by firstname" value="<?php echo ($search_firstname !== Null) ? $search_firstname : "" ?>">
        </div>
        <div class="form-group col-md-4">
          <select class="form-control" id="search_batch" name="search_batch">
            <option value="" selected="selected">Select Batch</option>
            <?php
            if ($batch_list !== Null) {
              while ($batch = $batch_list->fetch_assoc()) {
                echo '<option value="' . $batch["batch"] . '"' . (($search_batch !== Null) ?  (($search_batch == $batch["batch"]) ? 'selected="selected"' : '') : '') . ' >' . $batch["batch"] . '</option>';                
              }
            } ?>
          </select>
        </div>
        <div class="form-group col-md-4">
          <input type="submit" class="btn btn-primary" name="search" value="Search">
          <input type="submit" class="btn btn-secondary" name="reset" value="Reset">
        </div>
      </div>
    </form>
    <div>
      <table class="table table-light table-hover">
        <thead>
          <tr>
            <th>S.NO.</th>
            <th>Name</th>
            <th>DOB</th>
            <th>Email</th>
            <th>Mobile Number</th>
            <th>Gender</th>
            <th>Address</th>
            <th>Faculty</th>
            <th>Passed Year</th>
            <th>GPA</th>
            <th>Course</th>
            <th>Country Applied for</th>
            <th>Class Shift</th>
            <th>Batch</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php
          if ($students !== Null && $students->num_rows > 0) {
            while ($student = $students->fetch_assoc()) {
            if($student["course"]=='PTE'){
              $id = $student["id"];
              echo "<tr>";
              echo "<td>" .  $student["id"] . "</td>";
              echo "<td>" . $student["firstName"] . $student["middleName"] . $student["lastName"] . "</td>";
              echo "<td>" .  $student["dob"] . "</td>";
              echo "<td>" .  $student["email"] . "</td>";
              echo "<td>" .  $student["mobileNumber"] . "</td>";
              echo "<td>" .  $student["gender"] . "</td>";
              echo "<td>" .  $student["address"] . "</td>";
              echo "<td>" .  $student["faculty"] . "</td>";
              echo "<td>" .  $student["passedYear"] . "</td>";
              echo "<td>" . $student["gpa"] . "</td>";
              echo "<td>" .  $student["course"] . "</td>";
              echo "<td>" .  $student["countryAppliedFor"] . "</td>";
              echo "<td>" . $student["classShift"] . "</td>";
              echo "<td>" . $student["batch"] . "</td>";
              echo  "<td>
                    <a class='btnbtn-primaryme-2' href='addstudent.php?id=" . $id . "'><span class='material-icons'>edit</span></a>&nbsp;&nbsp;
                    <a class='btnbtn-danger' onclick='return confirm(\"Are you sure?\")' href='backend/delete_student.php?id=" . $id . "'><span class='material-icons'>delete_forever</span></a>
                    </td>";
              echo "</tr>";
                }
            }
          }
          else{
            echo "<tr><td>No records found</td></tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div>

<?php include("footer.php"); ?>