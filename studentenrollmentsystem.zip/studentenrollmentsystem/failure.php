    <?php include('sidebar.php');?>
    <div class="content">
        <h1> Error occured during the process. Please try again! </h1>
    </div>

    <?php include("footer.php");?>