<?php
require_once 'backend/db_connection.php';
require_once 'backend/retrieve_courses.php';

$courses = getAllCourses($conn);

?>
    <?php include('sidebar.php');?>
    <div class="content">
      <div class="card border" >
          <h3 class="text-white mb-4">Course Details</h3>
          <div class="table-responsive">
            <table class="table table-light table-hover">
              <thead>
                <tr>
                  <th>S.NO.</th>
                  <th>Course Name</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>                
                <?php
                if ($courses !== Null  && $courses->num_rows > 0) {
                  while ($course = $courses->fetch_assoc()) {
                    $id = $course["id"];
                    echo "<tr>";
                    echo "<td>" .   $id . "</td>";
                    echo "<td>" . $course["courseName"] . "</td>";     
                    echo  "<td>
                    <a class='btnbtn-primaryme-2' href='addcourse.php?id=" . $id . "'><span class='material-icons'>edit</span></a>&nbsp;&nbsp;
                    <a class='btnbtn-danger' onclick='return confirm(\"Are you sure?\")' href='backend/delete_course.php?id=" . $id . "'><span class='material-icons'>delete_forever</span></a>
                    </td>";              
                    echo "</tr>";
                  }
                }
                else{
                  echo "<tr><td>No records found</td></tr>";
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  
    <?php include("footer.php");?>