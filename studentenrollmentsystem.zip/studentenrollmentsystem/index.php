
<?php

require_once 'backend/db_connection.php';
require_once 'backend/retrieve_application_users.php';

session_start();

if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("Location: dashboard.php");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {    
    $username = $_POST['username'];
    $password = $_POST['password'];
    $isValidUser = isValidUser($conn,$username,$password);
    if ($isValidUser !== Null){
        $_SESSION["loggedin"] = true;
        $_SESSION["username"] = $username;
        header("Location: dashboard.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login Panel</title>
    <link rel="stylesheet" href="CSS/style.css">
</head>
<body>
    <div class="login-container">
        <div class="myform">
            <form method="post" action="">
                <h2>Admin Login</h2>
                <label>Username</label>
                <input type="text" placeholder="Username" name="username" required>
                <label>Password</label>
                <input type="password" placeholder="Password" name="password" required>
                <button type="submit">Login</button>
            </form>
        </div>
        <div class="image">
            <img src="images/logo.png">
        </div>
    </div>
</body>
</html>